README
Sam Disharoon

PSA-> My print funcion does not work. My print inOrder does, but the normal one does not.  There is also a disturbingly large memory leak because my destructor does not act right. It also likes to segfault on my laptop for some unknown reason. Maybe youll have better luck on your computer

a) My approach to the problem was to take the puesdocode offered in class, modify it slightly so it makes more sense to me, and then implement it.
b) The time complexity increases depending on how to tree is implemented.  If it is balanced, than it will be about log(n) time. An unbalanced tree will take n time though
c) I couldn't time it because of the segfaults
d) Making it a red-black tree
