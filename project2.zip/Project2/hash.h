//Project 2 ~> hash.h
//Sam Disharoon
#ifndef HASH_H
#define HASH_H
#include<string>
size_t hash(size_t);
size_t hash_str(std::string);
std::string hex(size_t);
#endif

