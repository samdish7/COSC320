README.TXT ~> Sam Disharoon
My approach to the problem was to take the hash fucntion I made in Lab 6, and implement it here.  To get which bucket each word has to get in, it uses the hash function, takes the results and does a % 8000 operation on it. IT takes the number that it is hashed, and it uses the hex function to make a key for it. There are alot of suggestions unfortunately, and the program in general takes a while to function. But it still works nonetheless. So theres that.  IT also doesn't work for other characters, only the alphabet.

