It keeps giving me this error "main.cpp:68:86: error: cannot convert ‘int (*)[6]’ to ‘int**’ for argument ‘1’ to ‘int fordFulkerson(int**, int, int)’
  std::cout<<"The maximum possible flow for graph 1 is ~> "<< fordFulkerson(graph1,0,5);" and I have no idea why it does this. Everything else seems to work fine (since there are no other errors), but I have no idea why this doesn't work.

